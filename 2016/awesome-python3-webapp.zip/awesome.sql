-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2016 �?09 �?12 �?21:03
-- 服务器版本: 5.5.40
-- PHP 版本: 5.6.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `awesome`
--

-- --------------------------------------------------------

--
-- 表的结构 `blogs`
--

CREATE TABLE IF NOT EXISTS `blogs` (
  `id` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_image` varchar(500) NOT NULL,
  `name` varchar(50) NOT NULL,
  `summary` varchar(200) NOT NULL,
  `content` mediumtext NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` varchar(50) NOT NULL,
  `blog_id` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_image` varchar(500) NOT NULL,
  `content` mediumtext NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pageurls`
--

CREATE TABLE IF NOT EXISTS `pageurls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- 转存表中的数据 `pageurls`
--

INSERT INTO `pageurls` (`id`, `site_id`, `name`, `url`, `created_at`) VALUES
(1, 3, '专题列表', '/special/', 1473658771.81833),
(2, 3, '植发价格', '/html/tfzz/5.html', 1473661755.99146),
(3, 3, '植发过程', '/html/tfzz/6.html', 1473661896.95453),
(4, 3, '植发危害', '/html/tfzz/7.html', 1473661922.51799),
(5, 3, '植发常识', '/html/tfzz/8.html', 1473661949.82855),
(6, 3, '斑秃', '/html/tfzz/9.html', 1473661979.00622),
(7, 3, '男性脱发', '/html/tfzz/10.html', 1473662012.03011),
(8, 3, '女性脱发', '/html/tfzz/11.html', 1473662028.95808),
(9, 3, '脱发等级', '/html/tfzz/12.html', 1473662048.43619),
(10, 3, '[专题]FDDH无痕植发', '/html/tfzz/19.html', 1473662111.98482),
(11, 3, '[专题]发际线种植', '/html/fjxtz/20.html', 1473662144.60369),
(12, 3, '[专题]疤痕植发', '/html/bhzz/21.html', 1473662171.42022),
(13, 3, '[专题]发际线调整', '/html/fjxtz/22.html', 1473662194.46354);

-- --------------------------------------------------------

--
-- 表的结构 `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `pid` int(11) DEFAULT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- 转存表中的数据 `projects`
--

INSERT INTO `projects` (`id`, `name`, `pid`, `created_at`) VALUES
(1, '无锡滨湖', 0, 1473563833.4275),
(2, '滨湖植发', 1, 1473568157.1245),
(3, '无锡五洲', 0, 1473583341.63789),
(4, '昆山长海', 0, 1473647324.48944),
(5, '滨湖性病', 1, 1473647339.4963),
(6, '滨湖皮肤', 1, 1473647353.59411),
(7, '五洲男科', 3, 1473647401.58785),
(8, '五洲妇科', 3, 1473647425.79924),
(9, '长海男科', 4, 1473647437.00488),
(10, '滨湖腋臭', 1, 1473649984.82139);

-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `passwd` varchar(50) NOT NULL,
  `admin` tinyint(1) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(500) NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_email` (`email`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `users`
--

INSERT INTO `users` (`id`, `email`, `passwd`, `admin`, `name`, `image`, `created_at`) VALUES
('0014734287396457a4fa48e158846de871713b0dd8218bf000', '200995968@qq.com', 'db207c88de9207bfedae99fea5072a8fc33d74a8', 1, 'wcj2020', 'http://www.gravatar.com/avatar/1e2b2aa349f1b796ad8390452079afa6?d=mm&s=120', 1473428739.64551),
('00147347234834094734be3d7884a8287aaa01848bb33ba000', '623895828@qq.com', '7c099028d3879677b5b59cd07e19af09d968ccc0', 1, 'test', 'http://www.gravatar.com/avatar/0ac634477896b3630efd8d079c3dc949?d=mm&s=120', 1473472348.34031),
('001473488703851c9e709588bca4e76aee34211c0f72333000', '717004735@qq.com', '2534cf2f0ac96f83cd13234fe025d2eca097d50b', 0, '污', '', 1473679785.2165),
('0014734888105366379b09075e441658c5edc3981991677000', '469673576@qq.com', '64a15044dba3553f072d86e13ddd38e9be59c6e9', 0, 'hello', '', 1473679770.75067),
('0014734893512856945f455a1a744a1bce4cac81eb73a5c000', '111@qq.com', '0c34c98b3312af0c3000c5f7c3ec8a998b4b2e0e', 0, 'jinja2', '', 1473679698.16052),
('00147368176028833fd6636cf474b3e9dad717d5718fac5000', '333@qq.com', 'a1c0cc32e059daa08a91aa814d38201db9e40214', 0, '测试用户', '', 1473681834.73689);

-- --------------------------------------------------------

--
-- 表的结构 `websites`
--

CREATE TABLE IF NOT EXISTS `websites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `project_id` int(11) NOT NULL,
  `ismobile` tinyint(1) NOT NULL,
  `sites` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `websites`
--

INSERT INTO `websites` (`id`, `name`, `project_id`, `ismobile`, `sites`, `created_at`) VALUES
(1, '滨湖植发', 2, 0, '{1: ''http://zhifa.bhpfbyy.com/'',2: ''http://zhifa.wxpfbyy120.com/''}', 1473579413.55789),
(3, '滨湖植发', 2, 1, '{1: ''http://vip.wxpfbyy120.com/'', 2: ''http://3g.bhpfbyy.com/''}', 1473579658.52423),
(4, '滨湖性病手机站', 5, 1, '{1: ''http://m.85878078.com/'', 2: ''http://6g.wxpfbyy120.com/''}', 1473652906.98253);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
