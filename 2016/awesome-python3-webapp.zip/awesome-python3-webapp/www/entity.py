import asyncio
import sqlalchemy as sa
from sqlalchemy.types import *
from sqlalchemy.sql import func
import time,uuid,hashlib

from aiomysql.sa import create_engine


metadata=sa.MetaData()


users = sa.Table('users', metadata,
               sa.Column('id', Integer, primary_key=True),
               sa.Column('email',String(50)),
               sa.Column('passwd',String(50)),
               sa.Column('image',String(500)),
               sa.Column('admin',BOOLEAN),
               sa.Column('name', String(255)),
               sa.Column('created_at',FLOAT())
                 )


def next_id():
    return '%015d%s000' % (int(time.time() * 1000),uuid.uuid4().hex)


def pwd_user(id,passwd):
    sha1 = hashlib.sha1()
    sha1.update(id.encode('utf-8'))
    sha1.update(b':')
    sha1.update(passwd.encode('utf-8'))
    return sha1.hexdigest()


@asyncio.coroutine
def create_pool(loop,**kw):
    global __pool
    __pool = yield from create_engine(
        host = kw.get('host','127.0.0.1'),
        port = kw.get('port',3306),
        user = kw['user'],
        password = kw['password'],
        db = kw['db'],
        charset = kw.get('charset','utf8'),
        autocommit = kw.get('autocommit',True),
        maxsize = kw.get('maxsize',10),
        minsize = kw.get('minsize',1),
        loop = loop
    )


@asyncio.coroutine
def go(in_loop):
    yield from create_pool(in_loop,user='root',password='root',db='awesome')
    global __pool
    with (yield from __pool) as conn:
        user_id=next_id()
        print(users.insert().values(name='jinja2',id=user_id,passwd=pwd_user(user_id,'123456'),
                                                       email='222@qq.com',image='image:blank'))
        res = yield from conn.execute(users.select())
        for row in res:
            print(row)


loop=asyncio.get_event_loop()
loop.run_until_complete(go(loop))

__pool.close()
loop.run_until_complete(__pool.wait_closed())
loop.close()