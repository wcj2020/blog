import re

t='http://3g.bhpfbyy.com/special/as.html'
m = re.match(r'^(http://\w+?\.\w+\.\w+)((/\w+)+)?(/\w+(\.)?\w+)?(/)?$',t)
if m:
    print(m.group(1),t.replace(m.group(1),''))
