import aiohttp_jinja2,jinja2,hashlib,logging; logging.basicConfig(level=logging.INFO)
from apis import Page, APIValueError, APIResourceNotFoundError
from models import User,Project,Website,Pageurl,next_id
from aiohttp import web
from urllib import parse
from aiohttp_session import get_session, session_middleware
from aiohttp_session.cookie_storage import EncryptedCookieStorage
import json,time,re

COOKIE_NAME = 'awesession'

@aiohttp_jinja2.template('test.html')
async def index(request):
    __user__= await get_user(request)
    users = await User.findAll()
    return {
        'users':users,
        '__user__':__user__
    }


@aiohttp_jinja2.template('signin.html')
async def signin(request):
    return {

    }

@aiohttp_jinja2.template('register.html')
async def register(request):
    return {

    }

@aiohttp_jinja2.template('user/list.html')
async def users(request):
    qs = request.query_string
    kw = dict()
    if qs:
        for k, v in parse.parse_qs(qs, True).items():
            kw[k] = v[0]
    page = kw.get('page', "1")
    __user__ = await get_user(request)
    users = await User.findAll('admin=?',[0])
    return {
        'page_index':page,
        'users': users,
        '__user__': __user__
    }

async def users_api(request):
    qs = request.query_string
    if qs:
        kw = dict()
        for k, v in parse.parse_qs(qs, True).items():
            kw[k] = v[0]
    page = kw.get('page', "1")
    page_index = get_page_index(page)
    num = await User.findNumber('count(id)','admin=?',[0])
    p = Page(num, page_index)
    r = web.Response()
    if num == 0:
        json_ret(r, dict(page=p.default(p), items=()))
        return r

    items = await User.findAll('admin=?',[0], orderBy='created_at asc', limit=(p.offset, p.limit))
    json_ret(r, dict(page=p.default(p), items=items))
    return r

@aiohttp_jinja2.template('user/create.html')
async def user_create(request):
    qs = request.query_string
    kw = dict()
    if qs:
        for k, v in parse.parse_qs(qs, True).items():
            kw[k] = v[0]
    _id = kw.get('id', "")
    __user__ = await get_user(request)
    return {
        'id':_id,
        '__user__': __user__
    }

async def user_create_api(request):
    ct = request.content_type.lower()
    if ct.startswith('application/json'):
        params = await request.json()
        if not isinstance(params, dict):
            return web.HTTPBadRequest('JSON body must be object.')
        name=params['name']
        email=params['email']
        passwd=params['passwd']
        if params['id']:
            sha1 = hashlib.sha1()
            sha1.update(params['id'].encode('utf-8'))
            sha1.update(b':')
            sha1.update(passwd.encode('utf-8'))
            passwd = sha1.hexdigest()
            site = User(name=name, email=email,admin=0,passwd=passwd,created_at=time.time(),
                           id=params['id'])
            await site.update()
        else:
            id=next_id()
            sha1 = hashlib.sha1()
            sha1.update(id.encode('utf-8'))
            sha1.update(b':')
            sha1.update(passwd.encode('utf-8'))
            passwd = sha1.hexdigest()
            site = User(id=id,name=name,image='about:blank;',email=email,passwd=passwd)
            await site.save()
        r = web.Response()
        json_ret(r, site)
        return r

async def signout(request):
    referer = request.headers.get('Referer')
    r = web.HTTPFound(referer or '/')
    session = await get_session(request)
    session[COOKIE_NAME]=None
    logging.info('user signed out.')
    return r

async def authenticate(request):
    r = web.Response()
    data={}
    ct = request.content_type.lower()
    if ct.startswith('application/json'):
        params = await request.json()
        if not isinstance(params, dict):
            return web.HTTPBadRequest('JSON body must be object.')
        data = params
    if not data['email']:
        json_ret(r, dict(error='email error', data='email', message='invalid email'))
        return r
    if not data['passwd']:
        json_ret(r, dict(error='passwd error', data='passwd', message='invalid passwd'))
        return r
    users = await User.findAll('email=?', [data['email']])
    if len(users) == 0:
        raise APIValueError('email', 'Email not exist.')
    user = users[0]

    # check passwd:
    sha1 = hashlib.sha1()
    sha1.update(user.id.encode('utf-8'))
    sha1.update(b':')
    sha1.update(data['passwd'].encode('utf-8'))
    if user.passwd != sha1.hexdigest():
        json_ret(r,dict(error='passwd error',data='passwd',message='invalid passwd'))
        return r

    session = await get_session(request)
    session[COOKIE_NAME] = user

    user.passwd = '******'
    json_ret(r,user)
    return r


async def get_user(request):
    session = await get_session(request)
    if session.__contains__(COOKIE_NAME):
        return session[COOKIE_NAME]
    else:
        return None


#set response content_type and response body of json type
def json_ret(r,msgs):
    r.content_type = 'application/json'
    r.body = json.dumps(msgs, ensure_ascii=False).encode('utf-8')

@aiohttp_jinja2.template('403.html')
async def forbidden(request):
    qs = request.query_string
    kw = dict()
    if qs:
        for k, v in parse.parse_qs(qs, True).items():
            kw[k] = v[0]
    url = kw.get('url', "Anonymous")
    return {
        'url':url
    }

#Project

@aiohttp_jinja2.template('project/create.html')
async def project_create(request):
    qs = request.query_string
    kw = dict()
    if qs:
        for k, v in parse.parse_qs(qs, True).items():
            kw[k] = v[0]
    id = kw.get('id', "")
    __user__ = await get_user(request)
    projects = await Project.findAll('pid=0')
    return {
        'id':id,
        'projects': projects,
        '__user__': __user__
    }

@aiohttp_jinja2.template('project/list.html')
async def projects(request):
    __user__ = await get_user(request)
    projects = await Project.findAll('pid=0')
    return {
        'projects': projects,
        '__user__': __user__
    }

async def project_create_api(request):
    ct = request.content_type.lower()
    if ct.startswith('application/json'):
        params = await request.json()
        if not isinstance(params, dict):
            return web.HTTPBadRequest('JSON body must be object.')
        data = params
    if data['id']:
        project = Project(name=data['name'], pid=data['pid'],id=data['id'],created_at=time.time())
        await project.update()
    else:
        project = Project(name=data['name'],pid=data['pid'])
        await project.save()
    r=web.Response()
    json_ret(r, project)
    return r

async def project_find_api(request):
    id = request.match_info.get('id', "")
    if id is not None:
        project=await Project.find(id)
        if project:
            r = web.Response()
            json_ret(r, project)
            return r

async def site_find_api(request):
    id = request.match_info.get('id', "")
    if id is not None:
        project=await Website.find(id)
        if project:
            r = web.Response()
            json_ret(r, project)
            return r

async def user_find_api(request):
    id = request.match_info.get('id', "")
    if id is not None:
        project=await User.find(id)
        if project:
            r = web.Response()
            json_ret(r, project)
            return r

async def url_find_api(request):
    id = request.match_info.get('id', "")
    if id is not None:
        project=await Pageurl.find(id)
        if project:
            r = web.Response()
            json_ret(r, project)
            return r

async def projects_api(request):
    qs = request.query_string
    kw = dict()
    if qs:
        for k, v in parse.parse_qs(qs, True).items():
            kw[k] = v[0]
    page = kw.get('page', "1")
    page_index = get_page_index(page)
    num = await Project.findNumber('count(id)')
    p = Page(num, page_index)
    r = web.Response()
    if num == 0:
        return dict(page=p, projects=())
    projects = await Project.findAll(orderBy='created_at asc',limit=(p.offset,p.limit))
    json_ret(r,dict(page=p.default(p),projects=projects))
    return r

async def sites_api(request):
    qs = request.query_string
    if qs:
        kw = dict()
        for k, v in parse.parse_qs(qs, True).items():
            kw[k] = v[0]
    page = kw.get('page', "1")
    project_id = kw.get('project_id', "0")
    page_index = get_page_index(page)
    num = await Website.findNumber('count(id)','project_id=?',[project_id])
    p = Page(num, page_index)
    r = web.Response()
    if num == 0:
        json_ret(r, dict(page=p.default(p), items=()))
        return r

    items = await Website.findAll('project_id=?',[project_id], orderBy='created_at asc', limit=(p.offset, p.limit))
    json_ret(r, dict(page=p.default(p), items=items))
    return r

#site
@aiohttp_jinja2.template('site/create.html')
async def site_create(request):
    qs = request.query_string
    kw = dict()
    if qs:
        for k, v in parse.parse_qs(qs, True).items():
            kw[k] = v[0]
    site_id = kw.get('id', "")
    __user__ = await get_user(request)
    id = request.match_info.get('project_id', "0")
    project = await Project.find(id)
    if project is None:
        raise APIResourceNotFoundError('project')
    if project.pid == 0:
        raise APIResourceNotFoundError('main project can\'t add site')
    return {
        'id':site_id,
        'project': project,
        '__user__': __user__
    }

@aiohttp_jinja2.template('site/list.html')
async def sites(request):
    qs = request.query_string
    kw = dict()
    if qs:
        for k, v in parse.parse_qs(qs, True).items():
            kw[k] = v[0]
    page = kw.get('page', "1")
    __user__ = await get_user(request)
    id = request.match_info.get('project_id', "0")
    project = await Project.find(id)
    return {
        'page_index':page,
        'project': project,
        '__user__': __user__
    }


async def site_create_api(request):
    ct = request.content_type.lower()
    if ct.startswith('application/json'):
        params = await request.json()
        if not isinstance(params, dict):
            return web.HTTPBadRequest('JSON body must be object.')
        name=params['name']
        project_id=params['project_id']
        ismobile=params['ismobile']
        sites=str(text2json(params['sites']))
        if params['id']:
            site = Website(name=name, project_id=project_id, ismobile=ismobile, sites=sites, created_at=time.time(),
                           id=params['id'])
            await site.update()
        else:
            site = Website(name=name, project_id=project_id, ismobile=ismobile, sites=sites)
            await site.save()
        r = web.Response()
        json_ret(r, site)
        return r

#pageurl
async def urls_api(request):
    qs = request.query_string
    if qs:
        kw = dict()
        for k, v in parse.parse_qs(qs, True).items():
            kw[k] = v[0]
    page = kw.get('page', "1")
    query = kw.get('query','')
    project_id = kw.get('site_id', "0")
    page_index = get_page_index(page)
    if query:
        num = await Pageurl.findNumber('count(id)','site_id=? and INSTR(name,?)>0',[project_id,query])
    else:
        num = await Pageurl.findNumber('count(id)','site_id=?',[project_id])
    p = Page(num, page_index)
    r = web.Response()
    if num == 0:
        json_ret(r, dict(page=p.default(p), items=()))
        return r
    if query:
        items = await Pageurl.findAll("site_id=? and INSTR(name,?)>0",[project_id,query], orderBy='id desc', limit=(p.offset, p.limit))
    else:
        items = await Pageurl.findAll('site_id=?',[project_id], orderBy='id desc', limit=(p.offset, p.limit))
    json_ret(r, dict(page=p.default(p), items=items))
    return r


@aiohttp_jinja2.template('url/create.html')
async def url_create(request):
    qs = request.query_string
    kw = dict()
    if qs:
        for k, v in parse.parse_qs(qs, True).items():
            kw[k] = v[0]
    url_id = kw.get('id', "")
    __user__ = await get_user(request)
    id = request.match_info.get('site_id', "0")
    project = await Website.find(id)
    if project is None:
        raise APIResourceNotFoundError('website')
    return {
        'id':url_id,
        'site': project,
        '__user__': __user__
    }


@aiohttp_jinja2.template('url/list.html')
async def urls(request):
    qs = request.query_string
    kw = dict()
    if qs:
        for k, v in parse.parse_qs(qs, True).items():
            kw[k] = v[0]
    page = kw.get('page', "1")
    query=kw.get('query',"")
    __user__ = await get_user(request)
    id = request.match_info.get('site_id', "0")
    project = await Website.find(id)
    return {
        'page_index':page,
        'query':query,
        'site': project,
        '__user__': __user__
    }


async def url_create_api(request):
    ct = request.content_type.lower()
    if ct.startswith('application/json'):
        params = await request.json()
        if not isinstance(params, dict):
            return web.HTTPBadRequest('JSON body must be object.')
        name=params['name']
        site_id=params['site_id']
        url=params['url']
        #regex the domain and replace it by none  e.g  return /article/22.html
        m = re.match(r'^(http://\w+?\.\w+\.\w+)((/\w+)+)?(/\w+(\.)?\w+)?(/)?$',url)
        if m:
            url=url.replace(m.group(1),'')
        if params['id']:
            site = Pageurl(name=name, site_id=site_id, url=url, created_at=time.time(),
                           id=params['id'])
            await site.update()
        else:
            site = Pageurl(name=name, site_id=site_id, url=url)
            await site.save()
        r = web.Response()
        json_ret(r, site)
        return r


def get_page_index(page_str):
    p = 1
    try:
        p = int(page_str)
    except ValueError as e:
        pass
    if p < 1:
        p = 1
    return p


def text2json(text):
    ret = text.strip().split('\n')
    test = dict()
    i = 1
    for val in ret:
        test[i] = val.strip()
        i += 1
    return test