import os


def setup_routes(app, handler, project_root):
    add_route = app.router.add_route
    add_route('GET', '/', handler.index)
    add_route('GET', '/signin', handler.signin)
    add_route('GET', '/signout', handler.signout)
    add_route('GET', '/register', handler.register)
    add_route('POST', '/api/register', handler.user_create_api)

    add_route('GET', '/admin', handler.users)
    add_route('GET', '/admin/users', handler.users_api)
    add_route('GET', '/admin/user/create', handler.user_create)
    add_route('GET', '/admin/api/user/{id}', handler.user_find_api)
    add_route('POST', '/admin/user/create', handler.user_create_api)
    add_route('POST', '/api/authenticate', handler.authenticate)

    #error pages defined here...
    add_route('GET', '/403', handler.forbidden)

    #projects
    add_route('GET', '/admin/projects', handler.projects)
    add_route('GET', '/admin/api/projects', handler.projects_api)
    add_route('GET', '/admin/api/project/{id}', handler.project_find_api)

    add_route('GET','/admin/project/create',handler.project_create)
    add_route('POST', '/admin/project/create', handler.project_create_api)

    #website /admin/site/create  /admin/2/sites  /admin/api/sites
    add_route('GET', '/admin/{project_id}/site/create', handler.site_create)
    add_route('POST', '/admin/site/create', handler.site_create_api)
    add_route('GET', '/admin/{project_id}/sites', handler.sites)
    add_route('GET', '/admin/sites', handler.sites_api)
    add_route('GET', '/admin/api/site/{id}', handler.site_find_api)

    #pageurl
    add_route('GET', '/admin/{site_id}/url/create', handler.url_create)
    add_route('POST', '/admin/url/create', handler.url_create_api)
    add_route('GET', '/admin/{site_id}/urls', handler.urls)
    add_route('GET', '/admin/urls', handler.urls_api)
    add_route('GET', '/admin/api/url/{id}', handler.url_find_api)

    # static resources
    app.router.add_static('/static/', os.path.join(project_root, 'static'))
    app.router.add_static('/uikit/', os.path.join(project_root, 'uikit'))
    app.router.add_static('/html/', os.path.join(project_root, 'html'))