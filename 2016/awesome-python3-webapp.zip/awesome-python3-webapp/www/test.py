#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import logging; logging.basicConfig(level=logging.INFO)
import asyncio,os,json,time
from models import User
from aiohttp import web
from orm import create_pool,destory_pool
from jinja2 import Environment,Template,TemplateNotFound,FileSystemLoader
from aiohttp_session import get_session, session_middleware
from aiohttp_session.cookie_storage import EncryptedCookieStorage
import aiohttp_jinja2
import handler
import routes
from datetime import datetime

COOKIE_NAME = 'awesession'

def datetimeformat(value):
    dt = datetime.fromtimestamp(value)
    return u'%s年%s月%s日' % (dt.year, dt.month, dt.day)

def jsonformat(value):
    items=json.loads(value)
    str=''
    for k,v in items:
        str +='<option value="%s">%s</option>'% (v,v)
    return str


def json_error(message):
    return web.Response(
        body=json.dumps({'error': message}).encode('utf-8'),
        content_type='application/json')

async def error_middleware(app, handler):
    async def middleware_handler(request):
        try:
            logging.info('--- error_middleware %s ---'% request.path)
            if request.path.startswith('/admin'):
                logging.info('--start with /admin--')
                session = await get_session(request)
                if session.__contains__(COOKIE_NAME) and session[COOKIE_NAME]:
                    pass
                else:
                    response = web.HTTPFound('/403?url=%s'% request.path)
                    return response

            response = await handler(request)
            if response.status == 404:
                return json_error(response.message)
            return response
        except web.HTTPException as ex:
            if ex.status == 404:
                return json_error(ex.reason)
            raise
    return middleware_handler

async def test(in_loop):
    await create_pool(in_loop,user='root',password='root',db='awesome')
    app = web.Application(loop=in_loop,middlewares=[session_middleware(EncryptedCookieStorage(b'2262PMfCyVWFiLJz2262PMfCyVWFiLJz')),error_middleware])

    project_root=os.path.dirname(os.path.abspath(__file__))
    aiohttp_jinja2.setup(app, loader=FileSystemLoader(os.path.join(project_root,'html'),encoding='utf-8'))

    #jinja2 template tag defined here...
    jinja_env=aiohttp_jinja2.get_env(app)
    jinja_env.filters['datetimeformat'] = datetimeformat
    jinja_env.filters['jsonformat'] = jsonformat

    routes.setup_routes(app,handler,project_root)

    srv = await in_loop.create_server(app.make_handler(),'127.0.0.1',9000)
    logging.info('server started at http://127.0.0.1:9000...')
    return srv

loop = asyncio.get_event_loop()
loop.run_until_complete(test(loop))
loop.run_forever()